import os 

image_data_with_features_pkl = os.path.join('meta-data-files/','image_data_features.pkl')
image_features_vectors_ann = os.path.join('meta-data-files/','image_features_vectors.ann')
